Silt
====

A recorder for messages this Windows PC sends to AI agents.
It is a local proxy. It is not a hidden sniffer, and it does not upload the tape.

What it saves
- Chat, completion, and message calls to known agent hosts
  (OpenAI, Anthropic, xAI, Gemini, Groq, Cursor, Copilot, and others).
- The prompt, the reply, the model, and rough token counts.
- Stored under %LOCALAPPDATA%\Silt\captures.jsonl

What it refuses to save
- Authorization headers, cookies, and API keys. Those are stripped first.
- Page bodies from ordinary sites. Those connections are counted, not opened.
- Traffic on someone else's machine. Run it only on a PC you own.

What it cannot see
- Apps that ignore the Windows proxy.
- Apps that pin their own certificate. Silt will not bypass that.
- Firefox, until you import %LOCALAPPDATA%\Silt\silt-ca.cer into Firefox.

Install
1. Unzip this folder.
2. Double-click Run-Silt.cmd.
3. Confirm the prompt, then approve the Windows certificate dialog.
4. Leave the window open. The desk is http://127.0.0.1:8878
5. Double-click Stop-Silt.cmd when you want your old proxy back.

Add a private gateway
Copy hosts.example.txt to %LOCALAPPDATA%\Silt\hosts.txt and list the host.
Restart Silt.

If the web stops loading after a crash, run Stop-Silt.cmd. That clears the proxy.
