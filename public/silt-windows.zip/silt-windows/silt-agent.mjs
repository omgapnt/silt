// Silt — local recorder for AI-agent calls on this machine.
// Binds to loopback only. Writes captures next to the user profile.
// Never stores Authorization, cookies, or API keys. Non-agent sites are
// tunneled without being opened, and only a byte count is kept.

import http from "node:http";
import https from "node:https";
import net from "node:net";
import tls from "node:tls";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import zlib from "node:zlib";
import crypto from "node:crypto";
import { fileURLToPath, pathToFileURL } from "node:url";
import forge from "node-forge";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const BUILTIN_HOSTS = [
  "api.openai.com",
  "chatgpt.com",
  "chat.openai.com",
  "api.anthropic.com",
  "claude.ai",
  "api.x.ai",
  "api.groq.com",
  "api.together.xyz",
  "api.together.ai",
  "openrouter.ai",
  "api.mistral.ai",
  "api.cohere.ai",
  "api.cohere.com",
  "api.perplexity.ai",
  "api.deepseek.com",
  "api.fireworks.ai",
  "generativelanguage.googleapis.com",
  "aiplatform.googleapis.com",
  "inference.huggingface.co",
  "router.huggingface.co",
  "api-inference.huggingface.co",
  "api.replicate.com",
  "api.githubcopilot.com",
  "copilot-proxy.githubusercontent.com",
  "api.individual.githubcopilot.com",
  "api2.cursor.sh",
  "api3.cursor.sh",
  "api.cursor.sh",
  "api.cursor.com",
  "gemini.google.com",
  "aistudio.google.com",
];

const BUILTIN_SUFFIXES = [".openai.azure.com"];

const AI_PATH =
  /\/(?:v1\/chat\/completions|v1\/completions|v1\/responses|v1\/messages|v1\/embeddings|chat\/completions|responses|messages|api\/chat|api\/generate|v1beta\/models\/[^?\s]+:(?:stream)?generateContent|openai\/deployments\/[^/\s]+\/(?:chat\/completions|completions)|v1\/engines\/[^/\s]+\/completions)/i;

const SECRET_KEY =
  /api[-_]?key|authorization|access[-_]?token|refresh[-_]?token|password|secret|cookie|credential|session/i;

const HOP = new Set([
  "connection",
  "proxy-connection",
  "keep-alive",
  "transfer-encoding",
  "upgrade",
  "te",
  "trailer",
  "proxy-authorization",
]);

export function hostIsAgent(host, extraRules = []) {
  const h = String(host || "")
    .toLowerCase()
    .replace(/\.$/, "")
    .replace(/^\[|\]$/g, "");
  if (!h) return false;
  if (BUILTIN_HOSTS.includes(h)) return true;
  if (BUILTIN_SUFFIXES.some((s) => h.endsWith(s))) return true;
  if (/^bedrock-runtime\.[a-z0-9-]+\.amazonaws\.com$/.test(h)) return true;
  if (/(^|\.)cursor\.sh$/.test(h) && h !== "cursor.sh") return true;
  for (const rule of extraRules) {
    const r = String(rule).trim().toLowerCase();
    if (!r || r.startsWith("#")) continue;
    if (r.startsWith(".")) {
      if (h.endsWith(r) || h === r.slice(1)) return true;
    } else if (h === r) return true;
  }
  return false;
}

export function isAiPath(pathname) {
  return AI_PATH.test(pathname || "");
}

export function scrubText(text) {
  return String(text)
    .replace(/\bsk-[A-Za-z0-9_\-]{10,}\b/g, "«redacted»")
    .replace(/\bsk-ant-[A-Za-z0-9_\-]{10,}\b/g, "«redacted»")
    .replace(/\bBearer\s+[A-Za-z0-9._\-~+/=]{8,}/gi, "Bearer «redacted»")
    .replace(
      /(api[_-]?key["']?\s*[:=]\s*["']?)[^"',\s}]+/gi,
      "$1«redacted»",
    );
}

export function redactValue(value) {
  if (Array.isArray(value)) return value.map(redactValue);
  if (value && typeof value === "object") {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = SECRET_KEY.test(k) ? "«redacted»" : redactValue(v);
    }
    return out;
  }
  if (typeof value === "string") return scrubText(value);
  return value;
}

function inflateNamed(buf, enc) {
  const name = enc.trim().toLowerCase();
  try {
    if (name === "zstd" || name === "zstandard") return zlib.zstdDecompressSync(buf);
    if (name === "br" || name === "brotli") return zlib.brotliDecompressSync(buf);
    if (name === "gzip" || name === "x-gzip") return zlib.gunzipSync(buf);
    if (name === "deflate") {
      try {
        return zlib.inflateSync(buf);
      } catch {
        return zlib.inflateRawSync(buf);
      }
    }
  } catch {
    return buf;
  }
  return buf;
}

function sniffCompressed(buf) {
  if (!buf || buf.length < 2) return buf;
  try {
    if (buf[0] === 0x1f && buf[1] === 0x8b) return zlib.gunzipSync(buf);
    if (buf.length >= 4 && buf[0] === 0x28 && buf[1] === 0xb5 && buf[2] === 0x2f && buf[3] === 0xfd) {
      return zlib.zstdDecompressSync(buf);
    }
    if (buf[0] === 0x78 && (buf[1] === 0x01 || buf[1] === 0x5e || buf[1] === 0x9c || buf[1] === 0xda)) {
      return zlib.inflateSync(buf);
    }
  } catch {
    return buf;
  }
  return buf;
}

export function encodingHeader(value) {
  if (Array.isArray(value)) return value.join(", ");
  if (value == null) return "";
  return String(value);
}

// Content-Encoding is applied left to right, so undo it from the right.
// Bytes stay bytes until this returns; callers convert to text only after.
export function decodeBody(buf, encoding) {
  let out = Buffer.isBuffer(buf) ? buf : Buffer.from(buf || []);
  if (out.length === 0) return out;
  const parts = encodingHeader(encoding)
    .toLowerCase()
    .split(",")
    .map((part) => part.trim())
    .filter((part) => part && part !== "identity");
  for (let i = parts.length - 1; i >= 0; i--) out = inflateNamed(out, parts[i]);
  const sniffed = sniffCompressed(out);
  return sniffed === out ? out : sniffCompressed(sniffed);
}

function textFromContent(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (!part || typeof part !== "object") return "";
        if (typeof part.text === "string") return part.text;
        if (typeof part.content === "string") return part.content;
        return "";
      })
      .filter(Boolean)
      .join("\n");
  }
  if (content && typeof content === "object" && typeof content.text === "string") {
    return content.text;
  }
  return "";
}

function pushMsg(out, role, text) {
  const clean = scrubText(text || "").trim();
  if (!clean) return;
  out.push({ role: role || "user", text: clean.slice(0, 100_000) });
}

function messagesFromJson(json) {
  const out = [];
  if (!json || typeof json !== "object") return out;
  if (typeof json.system === "string") pushMsg(out, "system", json.system);
  if (Array.isArray(json.system)) {
    for (const part of json.system) pushMsg(out, "system", textFromContent(part));
  }
  const lists = [json.messages, json.input].filter(Array.isArray);
  for (const list of lists) {
    for (const m of list) {
      if (!m || typeof m !== "object") continue;
      if (typeof m === "string") {
        pushMsg(out, "user", m);
        continue;
      }
      pushMsg(out, m.role || m.author || "user", textFromContent(m.content ?? m.text));
    }
  }
  if (typeof json.prompt === "string") pushMsg(out, "user", json.prompt);
  if (typeof json.input === "string") pushMsg(out, "user", json.input);
  if (Array.isArray(json.contents)) {
    for (const c of json.contents) {
      const text = (c.parts || []).map((p) => p?.text || "").join("\n");
      const role = c.role === "model" ? "assistant" : c.role || "user";
      pushMsg(out, role, text);
    }
  }
  return out;
}

function responseFromJson(json) {
  if (!json || typeof json !== "object") return "";
  const choice = json.choices?.[0];
  if (choice?.message) {
    const t = textFromContent(choice.message.content);
    if (t) return t;
  }
  if (typeof choice?.text === "string" && choice.text) return choice.text;
  if (Array.isArray(json.content)) {
    const t = json.content.map((c) => c?.text || textFromContent(c)).join("");
    if (t.trim()) return t;
  }
  if (typeof json.output_text === "string" && json.output_text) return json.output_text;
  if (Array.isArray(json.output)) {
    const t = json.output
      .map((o) => textFromContent(o?.content) || o?.text || "")
      .join("");
    if (t.trim()) return t;
  }
  const gemini = json.candidates?.[0]?.content?.parts?.map((p) => p?.text || "").join("");
  if (gemini && gemini.trim()) return gemini;
  if (typeof json.response === "string" && json.response) return json.response;
  if (json.message?.content) return textFromContent(json.message.content);
  return "";
}

function usageFrom(json) {
  const u = json?.usage || json?.usageMetadata;
  if (!u || typeof u !== "object") return null;
  const input = u.prompt_tokens ?? u.input_tokens ?? u.promptTokenCount ?? null;
  const output = u.completion_tokens ?? u.output_tokens ?? u.candidatesTokenCount ?? null;
  if (input == null && output == null) return null;
  return { input, output };
}

export function parseSse(text) {
  let acc = "";
  let model = null;
  let usage = null;
  for (const line of String(text).split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("data:")) continue;
    const data = trimmed.slice(5).trim();
    if (!data || data === "[DONE]") continue;
    let json;
    try {
      json = JSON.parse(data);
    } catch {
      continue;
    }
    if (typeof json.model === "string") model = json.model;
    const u = usageFrom(json);
    if (u) usage = u;
    const delta = json.choices?.[0]?.delta?.content;
    if (typeof delta === "string") acc += delta;
    if (json.delta?.text) acc += json.delta.text;
    if (typeof json.output_text === "string") acc += json.output_text;
    const gemini = json.candidates?.[0]?.content?.parts?.map((p) => p?.text || "").join("");
    if (gemini) acc += gemini;
  }
  return { text: scrubText(acc).trim(), model, usage };
}

function tryJson(buf) {
  const text = buf.toString("utf8").trim();
  if (!text || (text[0] !== "{" && text[0] !== "[")) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function providerFor(host) {
  const h = host.toLowerCase();
  if (h.includes("openai") || h.includes("chatgpt")) return "OpenAI";
  if (h.includes("anthropic") || h.includes("claude")) return "Anthropic";
  if (h.endsWith(".x.ai") || h === "x.ai" || h.includes("api.x.ai")) return "xAI";
  if (h.includes("googleapis") || h.includes("gemini") || h.includes("aistudio")) return "Google";
  if (h.includes("groq")) return "Groq";
  if (h.includes("mistral")) return "Mistral";
  if (h.includes("cohere")) return "Cohere";
  if (h.includes("perplexity")) return "Perplexity";
  if (h.includes("deepseek")) return "DeepSeek";
  if (h.includes("openrouter")) return "OpenRouter";
  if (h.includes("together")) return "Together";
  if (h.includes("fireworks")) return "Fireworks";
  if (h.includes("huggingface")) return "Hugging Face";
  if (h.includes("replicate")) return "Replicate";
  if (h.includes("copilot")) return "Copilot";
  if (h.includes("cursor")) return "Cursor";
  if (h.includes("bedrock") || h.includes("amazonaws")) return "Bedrock";
  if (h.includes("azure")) return "Azure OpenAI";
  if (h === "127.0.0.1" || h === "localhost") return "Local";
  return "Agent";
}

function safePath(p) {
  const s = String(p || "/");
  const q = s.indexOf("?");
  return q === -1 ? s : s.slice(0, q);
}

export function extractExchange({
  host,
  method,
  path: reqPath,
  status,
  reqBuf,
  resBuf,
  resType,
  latencyMs,
}) {
  const pathname = safePath(reqPath);
  const type = String(resType || "").toLowerCase();
  const reqText = (reqBuf || Buffer.alloc(0)).toString("utf8");
  const resTextRaw = (resBuf || Buffer.alloc(0)).toString("utf8");
  if (type.includes("javascript") || type.includes("css") || type.includes("image/") || type.includes("font")) {
    return null;
  }
  if (
    type &&
    !type.includes("json") &&
    !type.includes("text/plain") &&
    !type.includes("event-stream") &&
    !type.includes("eventstream") &&
    !type.includes("ndjson") &&
    !type.includes("text/xml")
  ) {
    return null;
  }
  if (/^\s*</.test(resTextRaw.slice(0, 80)) || type.includes("text/html")) return null;
  if (/^\s*</.test(reqText.slice(0, 40)) && !reqText.includes("{")) return null;

  const streaming = type.includes("event-stream") || resTextRaw.includes("\ndata:");
  const reqJson = tryJson(reqBuf || Buffer.alloc(0));
  const redactedReq = reqJson ? redactValue(reqJson) : null;
  let requestMessages = redactedReq ? messagesFromJson(redactedReq) : [];
  let responseText = "";
  let model = (redactedReq && (redactedReq.model || redactedReq.modelId)) || null;
  let usage = null;

  if (streaming) {
    const sse = parseSse(resTextRaw);
    responseText = sse.text;
    if (sse.model) model = sse.model;
    usage = sse.usage;
  } else {
    const resJson = tryJson(resBuf || Buffer.alloc(0));
    if (resJson) {
      const clean = redactValue(resJson);
      responseText = scrubText(responseFromJson(clean)).trim();
      if (clean.model) model = clean.model;
      usage = usageFrom(clean);
    }
  }

  const relevant =
    hostIsAgent(host) ||
    isAiPath(pathname) ||
    requestMessages.length > 0 ||
    /"messages"|"contents"|"choices"|"model"/.test(reqText);

  if (!relevant) return null;
  if (!requestMessages.length && reqText.trim()) {
    const snippet = scrubText(reqText).slice(0, 4000);
    if (snippet.trim()) requestMessages = [{ role: "raw", text: snippet }];
  }
  if (!responseText && !streaming) {
    const snippet = scrubText(resTextRaw).slice(0, 4000).trim();
    if (snippet && !snippet.startsWith("<")) responseText = snippet;
  }
  if (!requestMessages.length && !responseText) return null;

  return {
    id: crypto.randomUUID(),
    at: new Date().toISOString(),
    provider: providerFor(host),
    host,
    method: method || "POST",
    path: pathname,
    status: status || 0,
    model: model ? String(model) : null,
    latencyMs: latencyMs ?? 0,
    streaming,
    requestMessages,
    responseText: responseText.slice(0, 100_000),
    usage,
    bytesIn: reqBuf?.length || 0,
    bytesOut: resBuf?.length || 0,
    secretsStripped: true,
  };
}

function defaultDataDir() {
  if (process.env.SILT_DATA_DIR) return process.env.SILT_DATA_DIR;
  if (process.platform === "win32") {
    const base = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    return path.join(base, "Silt");
  }
  return path.join(os.homedir(), ".silt");
}

function loadRules(dataDir) {
  const rules = (process.env.SILT_EXTRA_HOSTS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  const file = path.join(dataDir, "hosts.txt");
  if (fs.existsSync(file)) {
    for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const t = line.trim();
      if (t && !t.startsWith("#")) rules.push(t);
    }
  }
  return rules;
}

function loadOrCreateCa(dataDir) {
  fs.mkdirSync(dataDir, { recursive: true });
  const keyPath = path.join(dataDir, "silt-ca.key.pem");
  const certPath = path.join(dataDir, "silt-ca.crt");
  const cerPath = path.join(dataDir, "silt-ca.cer");
  if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
    return {
      keyPem: fs.readFileSync(keyPath, "utf8"),
      certPem: fs.readFileSync(certPath, "utf8"),
      certPath,
      cerPath,
    };
  }
  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = "a1" + forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date(Date.now() - 60 * 60 * 1000);
  cert.validity.notAfter = new Date(Date.now() + 10 * 365 * 24 * 3600 * 1000);
  const attrs = [
    { name: "commonName", value: "Silt Local Recorder" },
    { name: "organizationName", value: "Silt" },
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs);
  cert.setExtensions([
    { name: "basicConstraints", cA: true, critical: true },
    { name: "keyUsage", keyCertSign: true, cRLSign: true, critical: true },
    { name: "subjectKeyIdentifier" },
  ]);
  cert.sign(keys.privateKey, forge.md.sha256.create());
  const keyPem = forge.pki.privateKeyToPem(keys.privateKey);
  const certPem = forge.pki.certificateToPem(cert);
  const der = forge.asn1.toDer(forge.pki.certificateToAsn1(cert)).getBytes();
  fs.writeFileSync(keyPath, keyPem, { mode: 0o600 });
  fs.writeFileSync(certPath, certPem);
  fs.writeFileSync(cerPath, Buffer.from(der, "binary"));
  return { keyPem, certPem, certPath, cerPath };
}

const leafCache = new Map();

function leafFor(host, ca) {
  const cached = leafCache.get(host);
  if (cached) return cached;
  const caCert = forge.pki.certificateFromPem(ca.certPem);
  const caKey = forge.pki.privateKeyFromPem(ca.keyPem);
  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = "b2" + forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date(Date.now() - 60 * 60 * 1000);
  cert.validity.notAfter = new Date(Date.now() + 365 * 24 * 3600 * 1000);
  cert.setSubject([{ name: "commonName", value: host }]);
  cert.setIssuer(caCert.subject.attributes);
  const altNames = net.isIP(host)
    ? [{ type: 7, ip: host }]
    : [{ type: 2, value: host }];
  cert.setExtensions([
    { name: "basicConstraints", cA: false },
    { name: "keyUsage", digitalSignature: true, keyEncipherment: true },
    { name: "extKeyUsage", serverAuth: true },
    { name: "subjectAltName", altNames },
  ]);
  cert.sign(caKey, forge.md.sha256.create());
  const material = {
    key: forge.pki.privateKeyToPem(keys.privateKey),
    cert: forge.pki.certificateToPem(cert) + ca.certPem,
  };
  leafCache.set(host, material);
  return material;
}

function stripHop(headers) {
  const out = {};
  for (const [k, v] of Object.entries(headers || {})) {
    if (HOP.has(k.toLowerCase())) continue;
    out[k] = v;
  }
  return out;
}

function readCaptures(file, limit) {
  if (!fs.existsSync(file)) return [];
  const stat = fs.statSync(file);
  let text;
  if (stat.size > 2_000_000) {
    const fd = fs.openSync(file, "r");
    const start = Math.max(0, stat.size - 1_500_000);
    const buf = Buffer.alloc(stat.size - start);
    fs.readSync(fd, buf, 0, buf.length, start);
    fs.closeSync(fd);
    text = buf.toString("utf8");
    const nl = text.indexOf("\n");
    if (nl !== -1) text = text.slice(nl + 1);
  } else {
    text = fs.readFileSync(file, "utf8");
  }
  const rows = [];
  for (const line of text.split(/\n/)) {
    if (!line.trim()) continue;
    try {
      rows.push(JSON.parse(line));
    } catch {
      /* skip a torn line */
    }
  }
  return rows.slice(-limit);
}

function dashboardHtml() {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Silt</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  html, body { margin: 0; height: 100%; background: #0c0b0a; color: #eceae4; font-family: "Segoe UI", sans-serif; }
  header { display: flex; justify-content: space-between; gap: 16px; align-items: flex-end; padding: 20px 24px; border-bottom: 1px solid #2e2a26; }
  h1 { font-family: Georgia, serif; font-weight: 500; font-size: 32px; margin: 0; letter-spacing: -0.03em; }
  p { margin: 4px 0 0; color: #8d877e; font-size: 14px; }
  button, a.btn { background: #eceae4; color: #0c0b0a; border: 0; border-radius: 6px; padding: 10px 14px; font: inherit; cursor: pointer; text-decoration: none; }
  button.ghost { background: transparent; color: #c9c2b6; border: 1px solid #2e2a26; }
  main { display: grid; grid-template-columns: minmax(240px, 340px) 1fr; height: calc(100% - 86px); }
  ul { list-style: none; margin: 0; padding: 8px; overflow: auto; border-right: 1px solid #2e2a26; }
  li { padding: 12px; border-radius: 8px; cursor: pointer; }
  li.on { background: #1f1c19; }
  .meta { color: #8d877e; font-size: 12px; }
  article { padding: 24px; overflow: auto; }
  pre { white-space: pre-wrap; font-family: Georgia, serif; font-size: 17px; line-height: 1.5; }
  .role { color: #b5523a; font-family: "Segoe UI", sans-serif; font-size: 12px; letter-spacing: 0.08em; text-transform: uppercase; margin-top: 18px; }
  @media (max-width: 800px) { main { grid-template-columns: 1fr; height: auto; } ul { max-height: 40vh; border-right: 0; border-bottom: 1px solid #2e2a26; } }
</style>
</head>
<body>
<header>
  <div>
    <h1>Silt</h1>
    <p id="stats">Reading this machine. Keys are stripped before anything is written.</p>
  </div>
  <div style="display:flex;gap:8px">
    <a class="btn" href="/api/captures?download=1">Export</a>
    <button class="ghost" id="clear" type="button">Clear tape</button>
  </div>
</header>
<main>
  <ul id="list"></ul>
  <article id="read"><p class="meta">No agent messages yet. Use a proxied app, then come back.</p></article>
</main>
<script>
const list = document.getElementById("list");
const read = document.getElementById("read");
let rows = [];
let current = null;
function esc(s){return String(s).replace(/[&<>"']/g, c => ({'&':'&','<':'<','>':'>','"':'"',"'":'&#39;'}[c]));}
function draw(){
  list.innerHTML = rows.map(r => {
    const preview = (r.requestMessages||[]).slice().reverse().find(m => m.role === "user") || (r.requestMessages||[])[0];
    const text = preview ? preview.text.replace(/\\s+/g," ").slice(0,140) : r.path;
    return '<li data-id="'+esc(r.id)+'" class="'+(r.id===current?'on':'')+'"><div class="meta">'+esc(r.provider)+' · '+esc(r.model||"model unknown")+'</div><div>'+esc(text)+'</div></li>';
  }).join("") || '<li class="meta">Nothing recorded yet.</li>';
  const row = rows.find(r => r.id === current) || rows[rows.length-1];
  if (!row) { read.innerHTML = '<p class="meta">No agent messages yet.</p>'; return; }
  current = row.id;
  const msgs = (row.requestMessages||[]).map(m => '<div class="role">'+esc(m.role)+'</div><pre>'+esc(m.text)+'</pre>').join("");
  read.innerHTML = '<div class="meta">'+esc(row.method)+' '+esc(row.host)+esc(row.path)+' · '+esc(row.status)+' · '+esc(row.latencyMs)+' ms</div>'+msgs+'<div class="role">Agent</div><pre>'+esc(row.responseText||"(empty)")+'</pre>';
}
async function refresh(){
  const [cap, stats] = await Promise.all([fetch("/api/captures"), fetch("/api/stats")]);
  rows = await cap.json();
  const s = await stats.json();
  document.getElementById("stats").textContent = s.aiCaptures+" agent messages saved · "+s.otherConnections+" other connections counted, not opened";
  if (!current && rows.length) current = rows[rows.length-1].id;
  draw();
}
list.addEventListener("click", (e) => {
  const li = e.target.closest("li");
  if (!li || !li.dataset.id) return;
  current = li.dataset.id;
  draw();
});
document.getElementById("clear").addEventListener("click", async () => {
  await fetch("/api/clear", { method: "POST", headers: { "x-silt-action": "clear" } });
  current = null;
  refresh();
});
refresh();
setInterval(refresh, 2000);
</script>
</body>
</html>`;
}

function isDirectRun() {
  const entry = process.argv[1];
  if (!entry) return false;
  return import.meta.url === pathToFileURL(path.resolve(entry)).href;
}

function main() {
  const dataDir = defaultDataDir();
  const initOnly = process.argv.includes("--init");
  const ca = loadOrCreateCa(dataDir);
  if (initOnly) {
    console.log(ca.cerPath);
    return;
  }

  const rules = loadRules(dataDir);
  const proxyPort = Number(process.env.SILT_PROXY_PORT || 8877);
  const uiPort = Number(process.env.SILT_UI_PORT || 8878);
  const captureFile = path.join(dataDir, "captures.jsonl");
  const insecure = process.env.SILT_INSECURE_UPSTREAM === "1";
  const stats = {
    startedAt: new Date().toISOString(),
    otherConnections: 0,
    otherBytes: 0,
    aiCaptures: 0,
    skipped: 0,
  };
  if (fs.existsSync(captureFile)) {
    try {
      stats.aiCaptures = fs.readFileSync(captureFile, "utf8").split("\n").filter(Boolean).length;
    } catch {
      /* ignore */
    }
  }

  let writeChain = Promise.resolve();
  function appendCapture(record) {
    writeChain = writeChain
      .then(() => fs.promises.appendFile(captureFile, JSON.stringify(record) + "\n"))
      .then(() => {
        stats.aiCaptures += 1;
      })
      .catch((err) => {
        console.error("silt write failed", err.message);
      });
  }

  const destBySocket = new WeakMap();

  function consider(meta) {
    const cap = 512 * 1024;
    const reqBuf = decodeBody(meta.reqBuf, meta.reqEncoding).subarray(0, cap);
    const resBuf = decodeBody(meta.resBuf, meta.resEncoding).subarray(0, cap);
    const record = extractExchange({
      host: meta.host,
      method: meta.method,
      path: meta.path,
      status: meta.status,
      reqBuf,
      resBuf,
      resType: meta.resType,
      latencyMs: meta.latencyMs,
    });
    if (!record) {
      stats.skipped += 1;
      return;
    }
    appendCapture(record);
  }

  function forward({ protocol, hostname, port, method, path: reqPath, headers, body, res }) {
    return new Promise((resolve) => {
      const started = Date.now();
      const lib = protocol === "http:" ? http : https;
      const reqHeaders = stripHop(headers);
      reqHeaders.host = port && port !== 80 && port !== 443 ? `${hostname}:${port}` : hostname;
      const upstream = lib.request(
        {
          protocol,
          hostname,
          port,
          method,
          path: reqPath,
          headers: reqHeaders,
          servername: hostname,
          rejectUnauthorized: !insecure,
          timeout: 300000,
        },
        (up) => {
          const chunks = [];
          let size = 0;
          const outHeaders = stripHop(up.headers);
          res.writeHead(up.statusCode || 502, outHeaders);
          up.on("data", (c) => {
            size += c.length;
            if (size <= 2_000_000) chunks.push(c);
            res.write(c);
          });
          up.on("end", () => {
            res.end();
            resolve({
              status: up.statusCode || 0,
              headers: up.headers,
              body: Buffer.concat(chunks),
              latencyMs: Date.now() - started,
            });
          });
        },
      );
      upstream.on("error", (err) => {
        const message = Buffer.from("Silt could not reach " + hostname + ": " + err.message);
        if (!res.headersSent) {
          res.writeHead(502, { "content-type": "text/plain" });
          res.end(message);
        } else {
          res.end();
        }
        resolve({
          status: 502,
          headers: { "content-type": "text/plain" },
          body: message,
          latencyMs: Date.now() - started,
          error: true,
        });
      });
      upstream.end(body || Buffer.alloc(0));
    });
  }

  async function handleAgentRequest(req, res, dest) {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 8_000_000) {
        res.writeHead(413);
        res.end("Silt refused an oversized body");
        return;
      }
      chunks.push(chunk);
    }
    const body = Buffer.concat(chunks);
    const protocol = dest.protocol || "https:";
    const result = await forward({
      protocol,
      hostname: dest.hostname,
      port: dest.port,
      method: req.method || "GET",
      path: dest.path || req.url || "/",
      headers: req.headers,
      body,
      res,
    });

    const pathname = safePath(dest.path || req.url || "/");
    const host = dest.hostname;
    if (hostIsAgent(host, rules) || isAiPath(pathname)) {
      consider({
        host,
        method: req.method,
        path: pathname,
        status: result.status,
        reqBuf: body,
        reqEncoding: encodingHeader(req.headers["content-encoding"]),
        resBuf: result.body,
        resType: result.headers["content-type"],
        resEncoding: encodingHeader(result.headers["content-encoding"]),
        latencyMs: result.latencyMs,
      });
    }
  }

  const mitmHttp = http.createServer((req, res) => {
    const dest = destBySocket.get(req.socket) || {
      hostname: (req.headers.host || "").split(":")[0],
      port: 443,
      protocol: "https:",
      path: req.url,
    };
    handleAgentRequest(req, res, { ...dest, path: req.url }).catch((err) => {
      if (!res.headersSent) res.writeHead(500);
      res.end(err.message);
    });
  });

  function mitm(clientSocket, host, port, head) {
    let creds;
    try {
      creds = leafFor(host, ca);
    } catch (err) {
      console.error("cert", err.message);
      clientSocket.destroy();
      return;
    }
    const tlsServer = tls.createServer({
      key: creds.key,
      cert: creds.cert,
      ALPNProtocols: ["http/1.1"],
    });
    tlsServer.on("secureConnection", (clear) => {
      destBySocket.set(clear, { hostname: host, port, protocol: "https:" });
      clear.on("error", () => clear.destroy());
      mitmHttp.emit("connection", clear);
    });
    tlsServer.on("tlsClientError", () => {
      try {
        clientSocket.destroy();
      } catch {
        /* gone */
      }
    });
    clientSocket.on("error", () => {
      try {
        tlsServer.close();
      } catch {
        /* gone */
      }
    });
    clientSocket.on("close", () => {
      try {
        tlsServer.close();
      } catch {
        /* gone */
      }
    });
    clientSocket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
    if (head && head.length) clientSocket.unshift(head);
    tlsServer.emit("connection", clientSocket);
  }

  function blindTunnel(clientSocket, host, port, head) {
    let counted = false;
    const upstream = net.connect(port, host, () => {
      clientSocket.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head && head.length) upstream.write(head);
      upstream.pipe(clientSocket);
      clientSocket.pipe(upstream);
    });
    const count = () => {
      if (counted) return;
      counted = true;
      stats.otherConnections += 1;
      stats.otherBytes += (clientSocket.bytesRead || 0) + (upstream.bytesRead || 0);
    };
    upstream.on("error", () => {
      count();
      clientSocket.destroy();
    });
    clientSocket.on("error", () => {
      count();
      upstream.destroy();
    });
    clientSocket.on("close", count);
  }

  const proxy = http.createServer((req, res) => {
    let url;
    try {
      url = new URL(req.url);
    } catch {
      res.writeHead(400);
      res.end("Silt expected a proxy-form URL");
      return;
    }
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => {
      const body = Buffer.concat(chunks);
      const fake = {
        method: req.method,
        url: url.pathname + url.search,
        headers: req.headers,
        async *[Symbol.asyncIterator]() {
          if (body.length) yield body;
        },
      };
      handleAgentRequest(fake, res, {
        protocol: url.protocol,
        hostname: url.hostname,
        port: Number(url.port) || (url.protocol === "https:" ? 443 : 80),
        path: url.pathname + url.search,
      }).catch((err) => {
        if (!res.headersSent) res.writeHead(502);
        res.end(err.message);
      });
    });
  });

  proxy.on("connect", (req, clientSocket, head) => {
    const target = req.url || "";
    const splitAt = target.lastIndexOf(":");
    const host = splitAt === -1 ? target : target.slice(0, splitAt);
    const port = Number(splitAt === -1 ? 443 : target.slice(splitAt + 1)) || 443;
    clientSocket.on("error", () => clientSocket.destroy());
    if (hostIsAgent(host, rules)) mitm(clientSocket, host, port, head);
    else blindTunnel(clientSocket, host, port, head);
  });

  proxy.on("clientError", (_err, socket) => {
    try {
      socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
    } catch {
      /* gone */
    }
  });

  const ui = http.createServer((req, res) => {
    const url = new URL(req.url || "/", "http://127.0.0.1");
    if (url.pathname === "/api/health") {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify({ ok: true, proxyPort, uiPort }));
      return;
    }
    if (url.pathname === "/api/stats") {
      res.writeHead(200, { "content-type": "application/json" });
      res.end(
        JSON.stringify({
          ...stats,
          proxyPort,
          uiPort,
          dataDir,
        }),
      );
      return;
    }
    if (url.pathname === "/api/captures") {
      const rows = readCaptures(captureFile, 200);
      if (url.searchParams.get("download")) {
        res.writeHead(200, {
          "content-type": "application/x-ndjson",
          "content-disposition": "attachment; filename=silt-captures.jsonl",
        });
        res.end(rows.map((r) => JSON.stringify(r)).join("\n"));
        return;
      }
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify(rows));
      return;
    }
    if (url.pathname === "/api/clear" && req.method === "POST") {
      if (req.headers["x-silt-action"] !== "clear") {
        res.writeHead(400);
        res.end("missing confirmation header");
        return;
      }
      fs.writeFileSync(captureFile, "");
      stats.aiCaptures = 0;
      res.writeHead(204);
      res.end();
      return;
    }
    if (url.pathname === "/" || url.pathname === "/index.html") {
      res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
      res.end(dashboardHtml());
      return;
    }
    res.writeHead(404);
    res.end("not found");
  });

  const pidFile = path.join(dataDir, "silt.pid");
  fs.writeFileSync(pidFile, String(process.pid));
  const shutdown = () => {
    try {
      fs.rmSync(pidFile, { force: true });
    } catch {
      /* ignore */
    }
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);

  proxy.on("error", (err) => {
    console.error("Silt proxy failed: " + err.message);
    process.exit(1);
  });
  ui.on("error", (err) => {
    console.error("Silt desk failed: " + err.message);
    process.exit(1);
  });

  proxy.listen(proxyPort, "127.0.0.1", () => {
    console.log("Silt proxy on 127.0.0.1:" + proxyPort);
  });
  ui.listen(uiPort, "127.0.0.1", () => {
    console.log("Silt desk on http://127.0.0.1:" + uiPort);
    console.log("Captures in " + captureFile);
  });
}

if (isDirectRun()) main();
